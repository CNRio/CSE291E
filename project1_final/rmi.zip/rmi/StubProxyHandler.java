package rmi;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;


public class StubProxyHandler implements InvocationHandler {
    protected InetSocketAddress serverSockAddr;
    public StubProxyHandler(InetSocketAddress address) {
        this.serverSockAddr = address;
    }

	@Override
    public Object invoke(Object proxy, Method method, Object[] objects) throws Throwable {
		if(method.getName().equals("toString") && method.getReturnType().
                getName().equals("java.lang.String") && method.
                getParameterTypes().length == 0) {
			StubProxyHandler result = (StubProxyHandler)java.lang.reflect.Proxy.getInvocationHandler(proxy);		
			return result.getClass().getName() + " " + result.getAddress().toString();
		}
		
		if(method.getName().equals("hashCode") && method.getParameterTypes().length == 0) {			
			StubProxyHandler result = (StubProxyHandler)java.lang.reflect.Proxy.getInvocationHandler(proxy);			
			return result.getClass().hashCode() * result.getAddress().hashCode();		
		}
		
		if(method.getName().equals("equals")&&method.getReturnType().getName().
                equals("boolean") && method.getParameterTypes().length == 1) {
			if(objects.length != 1 || objects[0] == null)
				return false;

			StubProxyHandler result1 = (StubProxyHandler)java.lang.reflect.Proxy.getInvocationHandler(proxy);
			StubProxyHandler result2 = (StubProxyHandler)java.lang.reflect.Proxy.getInvocationHandler(objects[0]);

			return (result1.getClass().equals(result2.getClass()) && 
				result1.getAddress().equals(result2.getAddress())) ? true : false;
		}

		boolean flag;
		SerializedObj res = null;
        Socket socket = null;
        try {
            socket = new Socket(serverSockAddr.getAddress(), serverSockAddr.getPort());
            ObjectOutputStream outputStream = new ObjectOutputStream((socket.getOutputStream()));
            outputStream.flush();
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
            outputStream.writeObject(method.getName());
            outputStream.writeObject(method.getParameterTypes());
            outputStream.writeObject(objects);            
            outputStream.flush();
            flag = (boolean) inputStream.readObject();
            res = (SerializedObj) inputStream.readObject();      
            socket.close();
        } catch (IOException | ClassNotFoundException e) {
        	throw new RMIException(e.getCause());
        } 
        if(!flag) throw (Exception) res.getReturnObj();	
    	return res.getReturnObj();
        
    }
    public InetSocketAddress getAddress() {
		return serverSockAddr; 
	}
}
